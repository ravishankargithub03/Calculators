package com.calculators.ten;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ten")
public class Ten extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Ten() 
    {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int hindi = Integer.parseInt(request.getParameter("hindi"));
		int result=1;
		if(hindi<33||hindi>100) result=0;
		int english = Integer.parseInt(request.getParameter("english"));
		if(english<33||english>100) result=0;
		int sanskrit = Integer.parseInt(request.getParameter("sanskrit"));
		if(sanskrit<33||sanskrit>100) result=0;
		int math = Integer.parseInt(request.getParameter("math"));
		if(math<33||math>100) result=0;
		int science = Integer.parseInt(request.getParameter("science"));
		if(science<33||science>100) result=0;
		int social = Integer.parseInt(request.getParameter("social"));
		if(social<33||social>100) result=0;
		String action = request.getParameter("action");
		int total=hindi+english+sanskrit+math+science+social;
		double totalNumber=total;
		double percentage=total/6;
		request.setAttribute("total", totalNumber);
		request.setAttribute("percentage", percentage);
		
		RequestDispatcher reqDis = request.getRequestDispatcher("ten.jsp");
		"result".equals(action);
		{
			if(result==1)
			{
				request.setAttribute("result", "Pass");
				reqDis.forward(request, response);
			}
			else 
			{
				request.setAttribute("result", "Fall");
				reqDis.forward(request, response);
			}
		}
	}

}
