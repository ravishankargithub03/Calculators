package com.calculators.simple_interest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/simpleinterest")
public class SimpleInterest extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public SimpleInterest() 
    {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int principal = Integer.parseInt(request.getParameter("principal"));
		double rateOfInterest = Double.parseDouble(request.getParameter("rateofinterest"));
		int time = Integer.parseInt(request.getParameter("time"));
		
		double simple=(principal*rateOfInterest*time)/100;
		double total=simple+principal;
		
		request.setAttribute("simple", simple);
		request.setAttribute("total", total);
		
		RequestDispatcher reqDis = request.getRequestDispatcher("simpleinterest.jsp");
		reqDis.forward(request, response);
	}

}
