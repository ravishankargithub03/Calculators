package com.calculators.twelve;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/twelve")
public class Twelve extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    public Twelve() 
    {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int hindi = Integer.parseInt(request.getParameter("hindi"));
		int result=1;
		if(hindi<33||hindi>100) result=0;
		int english = Integer.parseInt(request.getParameter("english"));
		if(english<33||english>100) result=0;
		int math = Integer.parseInt(request.getParameter("math"));
		if(math<33||math>100) result=0;
		int physics = Integer.parseInt(request.getParameter("physics"));
		if(physics<33||physics>100) result=0;
		int chemistry = Integer.parseInt(request.getParameter("chemistry"));
		if(chemistry<33||chemistry>100) result=0;
		int total=hindi+english+math+physics+chemistry;
		double totalNumber=total;
		double percentage=total/5;
		request.setAttribute("total", totalNumber);
		request.setAttribute("percentage", percentage);
		
		RequestDispatcher reqDis = request.getRequestDispatcher("twelve.jsp");
		String action = request.getParameter("action");
		
		"result".equals(action);
		{
			if(result==1)
			{
				request.setAttribute("result", "Pass");
				reqDis.forward(request, response);
			}
			else 
			{
				request.setAttribute("result", "Fall");
				reqDis.forward(request, response);
			}
		}
	}

}
